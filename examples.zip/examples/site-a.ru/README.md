Фрагмент кода на OctoberCMS (Laravel) 
