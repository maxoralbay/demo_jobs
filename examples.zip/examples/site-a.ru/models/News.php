<?php namespace Pp\Kistochki\Models;

use Model;
use Pp\Kistochki\Classes\BaseModel;

/**
 * Model
 */
class News extends BaseModel
{
    /**
     * @var string The database table used by the model.
     */
    public $table = 'pp_kistochki_news';

    /**
     * The attributes that aren't mass assignable.
     *
     * @var array
     */
    protected $guarded = [];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'published_at' => 'datetime',
    ];

    /**
     * The relationships that should always be loaded.
     *
     * @var array
     */
    // protected $with = ['images', 'seo'];

    /**
     * Belong to relationships definitions.
     */
    public $belongsTo = [
        'seo' => [Seo::class, 'key' => 'seo_id'],
        'images' => Image::class,
    ];

    /**
     * Polymorphic Relationships definitions.
     */
    public $morphToMany = [

    ];

    /**
     * @var array Validation rules
     */
    public $rules = [
        'title' => self::TITLE_RULE,
        'slug' => self::SLUG_RULE,
        'status' => self::STATUS_RULE,
        'text' => self::HTML_DESCRIPTION_RULE,
        'text_short' => self::TEXT_RULE,
    ];

    public $customMessages = [
        'title.required' => 'Заголовок обязателен',
        'title.min' => 'Заголовок должен быть не менее :min символов',
        'title.max' => 'Заголовок должен быть не более :max символов',
        'slug.required' => 'Ссылка обязательна',
        'slug.min' => 'Ссылка должна быть не менее :min символов',
        'slug.max' => 'Ссылка должна быть не более :max символов',
        'slug.invalid' => 'Ссылка не корректно',
        'text_short.max' => 'Короткий текст должен быть не более :max символов',
        'text_short.min' => 'Короткий текст должен быть не менее :min символов',
        'text.min' => 'Текст должен быть не менее :min символов',
        'text.max' => 'Текст должен быть не более :max символов',
        'category.required' => 'Категория обязательна',
        'seo.meta_title.min' => 'SEO заголовок должен быть не менее :min символов',
        'seo.meta_title.max' => 'SEO заголовок должен быть не более :max символов',
        'seo.meta_desc.min' => 'SEO описание должен быть не менее :min символов',
        'seo.meta_desc.max' => 'SEO описание быть не более :max символов',
    ];


    /**
     * @var array Attribute names to encode and decode using JSON.
     */
    public $jsonable = [];

    public function beforeSave()
    {
        parent::beforeSave();
        if(!$this->published_at) {
            $this->published_at = $this->updated_at;
        }
    }
}
