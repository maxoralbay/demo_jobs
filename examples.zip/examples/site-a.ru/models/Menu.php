<?php namespace Pp\Kistochki\Models;

use Pp\Kistochki\Classes\BaseModel;
use Illuminate\Support\Facades\Log;
/**
 * Model
 */
class Menu extends BaseModel
{
    /*
     * Disable timestamps by default.
     * Remove this line if timestamps are defined in the database table.
     */
    public $timestamps = false;


    /**
     * @var string The database table used by the model.
     */
    public $table = 'pp_kistochki_menus';

    /**
     * @var array Ucfirst keys from table.
     */
    protected $ucfirstKeys = ['title', 'menu_title', 'subtitle'];

//    protected $purgeable = ['type'];
    /**
     * @var array Validation rules
     */


    public $rules = [
        'title' => self::TITLE_RULE,
        'slug' => self::SLUG_RULE,
        'url' => self::URL_RULE,
        'menu_title' => self::TITLE_RULE,
        'column' => self::COLUMN_RULE,
        'subtitle' => self::SUBTITLE_RULE,
        'excerpt' => self::EXCERPT_RULE,
        'description' => self::DESCRIPTION_RULE,
        'status' => self::STATUS_RULE,
        'seo.meta_title' => self::SEO_TITLE_RULE,
        'seo.meta_desc' => self::SEO_DESC_RULE,
    ];

    public $customMessages = [
        'title.required' => 'Заголовок обязателен',
        'title.min' => 'Заголовок должен быть не менее :min символов',
        'title.max' => 'Заголовок должен быть не более :max символов',
        'url.min'=>'URL должен быть не более :min символов',
        'url.max'=>'URL должен быть не более :max символов',
        'url.invalid' => 'Ссылка не корректно',
        'excerpt.max' => 'Подзаголовок должен быть не более :max символов',
        'excerpt.min' => 'Подзаголовок должен быть не менее :min символов',
        'information.*.title.min' => 'Информация > Заголовок должен быть не менее :min символов',
        'information.*.title.max' => 'Информация > Заголовок должен быть не более :max символов',
        'information.*.description.min' => 'Информация > Описание должен быть не менее :min символов',
        'information.*.description.max' => 'Информация > Описание должен быть не более :max символов',
        'seo.meta_title.min' => 'SEO заголовок должен быть не менее :min символов',
        'seo.meta_title.max' => 'SEO заголовок должен быть не более :max символов',
        'seo.meta_desc.min' => 'SEO описание должен быть не менее :min символов',
        'seo.meta_desc.max' => 'SEO описание быть не более :max символов',
    ];

    /**
     * Relationships
     */

    public $belongsTo = [
        'seo' => [Seo::class, 'key' => 'seo_id'],
        'images' => Image::class,
    ];

    public $morphToMany = [

    ];

    // Load relations globally by default
    protected $with = ['seo', 'images'];
}
