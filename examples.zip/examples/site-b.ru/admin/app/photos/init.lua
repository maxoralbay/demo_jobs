local u = require("app.utils.utils")
local response = require("app.utils.response")
local errors = require("errors")
local vshard = require("vshard")
local fiber = require("fiber")
local magick = require("magick")
local uuid = require("uuid")
local check_session = require("app.roles.sessions").api().check_session
local err_vshard_router = errors.new_class("Vshard routing error")
local photosErr = errors.new_class("photos")

local photos = {}


-- extract photo raw data from request
-- @param req request object
-- @return photo data
function photos.base_photo_set(req, opts)
    local opts = opts or {}
    --u.logger('base_photos.photo_set', {})
    local data = u.form_data(req)
    local img_raw = data:get_all()
    local is_ok = false
    -- check with imageMagic
    local magick_status, _ = pcall(magick.load_image_from_blob, img_raw['photo'])
    -- check file type and size
    -- pcall
    if magick_status == false then
        log.error(photosErr:new("it is not an image"))
        return is_ok, {}
    end
    -- check it uuid?

    local photo_name, _ = u.get_field_attr('photo', data)
    -- validate name
    local _, crop_width = u.get_form('cropImgWidth', data)
    local _, crop_height = u.get_form('cropImgHeight', data)
    --local _, crop_x = u.get_form('cropImgX', data)
    --local _, crop_y = u.get_form('cropImgY', data)
    local _, type_photo = u.get_form('type_photo', data)
    crop_width = tonumber(crop_width)
    crop_height = tonumber(crop_height)
    photo_name = tostring(photo_name)
    type_photo = type_photo or opts.type_photo
    --crop_x = tonumber(crop_x)
    --crop_y = tonumber(crop_y)
    type_photo = string.match("main|slider|user|img|list|logo", type_photo)
    local is_valid_name = string.match(photo_name, "[%w%_%-]+.[webp]+$") == photo_name
    -- check photo name  is extend webp
    -- return if ext is same of file extension
    if (string.split(photo_name, '.')[#string.split(photo_name, '.')] == 'webp') == false then
        log.warn("it is not an webp image")
        return nil
    end
--u.logger('test photo', {#img_raw['photo'] <= CONF.IMG_PROPER.MAX_SIZE ,
--                            is_valid_name , #photo_name <= 128})
    -- if logo then change weight X height
    u.logger('height and width and valid name', {crop_height=crop_height, crop_width=crop_width, is_valid_name=is_valid_name})
    if #img_raw['photo'] <= CONF.IMG.MAX_SIZE  and
        is_valid_name and #photo_name <= 128 then

        -- get login from user_id
        local function prepare_photo_name(name)
            local photo_name_split = string.split(name:lower(), ".")
            return photo_name_split[1] .. "_" ..
                tostring(fiber.time64()):sub(-7, -4) .. "." ..
                photo_name_split[2] -- TODO check it
        end

        is_ok = true
        -- check type_photo
        -- TODO change logic of check inputs numbers
        return  {
            name = prepare_photo_name(photo_name),
            img_raw = img_raw['photo'],
            crop_width = crop_width,
            crop_height = crop_height,
            --crop_x = crop_x,
            --crop_y = crop_y,
            type_photo = type_photo
        }

    end

    return nil

end

-- Upload image of card data
-- @param {table} req
-- @param {table} opts = {id, func, }
-- @return {table} response
function photos.photo_set(req, opts)
    u.logger('photos.photo_set', opts)
    local err = nil
    local out_data = {}
    local resp = { status = false }
    local is_mini = false
    local photo_data = photos.base_photo_set(req, opts)
    --- does img has mini size
    if string.match(tostring(req:param('is_mini')),'true') =='true' then is_mini = true else is_mini = false end
    -- check photo is exist
    if photo_data == nil then
        --u.logger('photo processing has problem is_ok', is_ok)
        return response.internal_err('photo processing has problem is_ok')
    end
    -- Validate photo parameters
    ---- min validation
    ---
    --- does img has mini size

    local allow_is_mini = {'news'}
    -- check opts.name_caller is in allow_is_mini
    if u.in_table(opts.name_caller, allow_is_mini) == false then
        is_mini = false
    end
    u.logger('is_mini', is_mini)
    if is_mini then photo_data.type_photo = 'mini_'..photo_data.type_photo end
    u.logger('photo_data', {photo_data.type_photo, opts.TYPE_PHOTO_PARAMS[photo_data.type_photo], photo_data.crop_height, photo_data.crop_width})
    if not (photo_data.crop_height >= opts.TYPE_PHOTO_PARAMS[photo_data.type_photo].height or
        photo_data.crop_width >= opts.TYPE_PHOTO_PARAMS[photo_data.type_photo].width)
        --photo_data.crop_y >= opts.TYPE_PHOTO_PARAMS[photo_data.type_photo].height or
        --photo_data.crop_x >= opts.TYPE_PHOTO_PARAMS[photo_data.type_photo].width)
    then
        err = "cropImgWidth X cropImgHeight must be high "
        log.warn(photosErr:new(err))
        return response.internal_err(err)
    end

    -- check photo crop_width and crop_width if is_mini
    -- max validation
    if  not (photo_data.crop_height < CONF.IMG.RES or
        photo_data.crop_width < CONF.IMG.RES)
        --photo_data.crop_y < CONF.IMG.RES or
        --photo_data.crop_x < CONF.IMG.RES)
    then
        err = "cropImgWidth X cropImgHeight must be less"
        log.warn(photosErr:new(err))
        return response.internal_err(err)
    end

    u.logger('phot_set id', opts.id)
    local bucket_id = vshard.router.bucket_id_mpcrc32(opts.id)
    -- TODO add here func to get
    -- if empty then use a new name
    -- TODO here get by vshard

    local data = {
        id = opts.id,
        name = photo_data.name,
        crop_width = photo_data.crop_width,
        crop_height = photo_data.crop_height,
        --crop_x = photo_data.crop_x,
        --crop_y = photo_data.crop_y,
        type = photo_data.type_photo,
        img_raw = photo_data.img_raw,
        is_mini = is_mini
    }
    out_data, err = err_vshard_router:pcall(
        vshard.router.callrw,
        bucket_id,
        opts.func, { data },
        { timeout = 20 }
    )
    u.logger('out_data', {out_data=out_data, err=err})
    if err then
        log.error(photosErr:new(err))
        return response.internal_err("an error happened")
    end
    --u.logger('photo_data', out_data)
    if out_data then
        resp = out_data
    end

    return resp
end



return photos
