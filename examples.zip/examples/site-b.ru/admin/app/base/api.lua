--Docs
local check_session = require("app.roles.sessions").api().check_session
local u = require("app.utils.utils")
local errors = require("errors")
local apiErr = errors.new_class("api")
local response = require("app.utils.response")
local vshard = require("vshard")
local err_vshard_router = errors.new_class("Vshard routing error")
local api = {}

function api.all(req, model_func, data_func)
    req = check_session(req)
    if not req._opts['is_login'] then
        return response.unauth()
    end
    local resp = {}
    if not check_roles(get_roles_user(req._opts.user_id),
        CONF.PREFIX_APP .. model_func) then
        resp.msg = 'You don\'t have permission'
        return response.json(resp)
    end
    local err = nil
    local out_data = {}
    local status = true
    -- validation

    local data = data_func(req)
    out_data, err = err_vshard_router:pcall(vshard.router.callro, data.bucket_id,
        model_func, { data }, { timeout = 1 })
    if err then
        log.error(apiErr:new(err))
        return false
    end
    -- logic put here

    return response.json(out_data)
end

function api.upsert(req, model_func, data_func)
    local err = nil
    -- u.logger('req', req)
    req = check_session(req)
    if not req._opts['is_login'] then
        return response.unauth()
    end
    local resp = {}
    if not check_roles(get_roles_user(req._opts.user_id),
        CONF.PREFIX_APP .. 'api.upsert') then
        resp.msg = 'You don\'t have permission'
        return response.json(resp)
    end

    -- get data
    local out_data = {}
    local data = {}

    local _, input_data = pcall(function()
        return req:json()
    end)
    local id = input_data['id']

    -- check id if it exist then make it
    if id ~= nil then
        id = uuid.fromstr(id)
        if id == nil then
            return response.internal_err('id is not correct', id)
        end
    else
        id = uuid.new()
    end
    --u.logger('input_data',
    ---- TO DO: regexp validate input_data
    ---- Validate
    -- Before create id or check id
    if id ~= nil then
        -- validation data
        --{ 'id', 'uuid' },
        --{ 'bucket_id', 'unsigned' },
        --{ 'status', 'boolean' }, -- base
        --{ 'years', 'unsigned' }, -- {start=1, end=nil|some_number}
        --{ 'order', 'unsigned' }, --
        -- base
        -- TODO

        data = data_func(req, id)
        -- u.logger('data', data)

        out_data, err = err_vshard_router:pcall(vshard.router.callrw, data.bucket_id,
            model_func, { data },
            { timeout = 1 })
        log.warn("err", err)
        if err ~= nil then
            local msg = apiErr:new(err).str
            log.error(msg)

            return response.internal_err({
                error = "an error happened",
                msg = msg
            })
        end
        --u.logger('out_data', out_data)
        --
        if out_data then
            resp = out_data
        end
        return response.json(resp)

    end
    return response.json(resp)
end

-- Get one card data
function api.get(req, model_func, data_func)
    req = check_session(req)
    local err = nil
    if not req._opts['is_login'] then
        return response.unauth()
    end
    local resp = {}
    if not check_roles(get_roles_user(req._opts.user_id),
        CONF.PREFIX_APP .. 'api.one') then
        resp.msg = 'You don\'t have permission'
        return response.json(resp)
    end
    local out_data = {}
    -- after prepare data
    local data = data_func(req)
    u.logger('api data', data)
    out_data, err = err_vshard_router:pcall(vshard.router.callro, data.bucket_id,
        model_func, { data },
        { timeout = 1 })

    if err then
        log.error(apiErr:new(err))
        return false
    end
    -- logic put here
    return response.json(out_data)
end

-- by default hard delete
-- Delete a card data with file
function api.delete(req, model_func, data_func)
    local err = nil
    req = check_session(req)
    if not req._opts['is_login'] then
        return response.unauth()
    end
    local resp = { status = false }
    if not check_roles(get_roles_user(req._opts.user_id),
        CONF.PREFIX_APP .. 'api.delete') then
        resp.msg = 'You don\'t have permission'
        return response.json(resp)
    end
    local is_deleted = false

    local id = uuid.fromstr(req:stash("id"))
    if id == nil then
        return response.internal_err('id is not correct', id)
    end

    -- validation
    if id then

        local data = data_func(id)

        is_deleted, err = err_vshard_router:pcall(vshard.router.callrw,
            data.bucket_id, model_func,
            { data }, { timeout = 1 })

        if err then
            log.error(apiErr:new(err))
            return response.internal_err(resp)
        end
    end
    if is_deleted then
        resp = is_deleted
    end

    return response.json(resp)
end

-- Set order one card data
function api.order(req, model_func, data_func)
    local err = nil
    req = check_session(req)
    if not req._opts['is_login'] then
        return response.unauth()
    end
    local resp = {}
    -- if not check_roles(get_roles_user(req._opts.user_id), CONF.PREFIX_APP .. 'api.order') then
    --    resp.msg = 'You don\'t have permission'
    --    return response.json(resp)
    -- end
    -- local type = req:param('type') or 'order_list' -- or order_main
    local out_data = {}
    local input_data = data_func(req)
    local bucket_id = 0
    local type = req:param('type') or 'api' -- slider, slider_item
    out_data, err = err_vshard_router:pcall(vshard.router.callrw, data.bucket_id,
        model_func, { input_data },
        { timeout = 1 })

    if err then
        log.error(apiErr:new(err))
        return false
    end
    -- logic put here
    resp = out_data
    return response.json(resp)
end

return api
