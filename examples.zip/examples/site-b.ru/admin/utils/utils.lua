local utils = {}
local digest = require('digest')
local fiber = require('fiber')
local math = require('math')
local log = require('log')
local json = require('json')
local fio = require('fio')
local uuid = require("uuid")
local http_client = require('http.client').new({ max_connections = 5 })
-- multipart decoder
-- @link https://github.com/Kong/lua-multipart
local mp = require("multipart")
-- work with image
-- @link https://github.com/leafo/magick
local magick = require("magick")
utils.PATH_IMG_TABLE = {}
function utils.now()
    return math.floor(fiber.time())
end
function utils.tnow()
    return os.time()
end
-- convert date to timestamp
-- @param time = {year=year, month=month, day=day, hour=0, min=0, sec=0}
-- @return timestamp
function utils.to_timestamp(time)
    return os.time(time)
end
function utils.get_only_date(timestamp)
    local splitted_date = string.split(os.date('%d-%m-%Y', timestamp), '-')
    return {
        day = splitted_date[1],
        month = splitted_date[2],
        year = splitted_date[3],
        hour = 0,
        min = 0,
        sec = 0
    }
end
function utils.get_day_of_week(dd, mm, yy)
    local dw = os.date('*t', os.time { year = yy, month = mm, day = dd })['wday']
    return dw - 1, ({ "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" })[dw]
end
function utils.format(string, tab)
    return (string:gsub('($%b{})',
        function(word)
            return tab[word:sub(3, -2)] or word
        end))
end

function utils.format_update(tuple)
    local fields = {}
    for number, value in pairs(tuple) do
        table.insert(fields, { '=', number, value })
    end
    return fields
end

function utils.dump(o)
    if type(o) == 'table' then
        local s = '{ '
        for k, v in pairs(o) do
            if type(k) ~= 'number' then
                k = '"' .. k .. '"'
            end
            s = s .. '[' .. k .. '] = ' .. utils.dump(v) .. ','
        end
        return s .. '} '
    else
        return tostring(o)
    end
end

function utils.base64_encode(string)
    return string.gsub(digest.base64_encode(string), '\n', '')
end

function utils.lower(string)
    -- if validator.string(string) then
    --     return string:lower()
    -- end
end

function utils.gen_random_key(key_len)
    return string.hex(digest.urandom(key_len or 10))
end

function utils.salted_hash(str, salt)
    return digest.sha256(string.format('%s%s', salt, str))
end
function utils.logger(msg, ...)
    if DEBUG and true then
        if msg ~= nil then
            log.info(msg .. ':')
        end
        log.info(...)
    end
end
-- get data from form-data
-- mp = require("multipart")
-- requirement:  data = mp(raw_data, req.headers["content-type"])
function utils.get_form(param, data)
    return pcall(function(param, data)
        local param_data = data:get(param)
        if param_data == nil then
            return param_data
        end
        if param_data.value then
            -- utils.logger("get_form", param_data)
            return param_data.value
        end
    end, param, data)

end

function utils.form_data(req)
    local raw_data = req:read() or ""
    return mp(raw_data, req.headers["content-type"])
end

function utils.get_meta_data(data)
    -- save_post_data(post_data, req)
    local meta_data = data:get("meta_data") or "{}"
    -- convert to object
    meta_data = json.decode(meta_data["value"] or "{}")

    if meta_data == nil then
        resp.err = "meta_data is empty"
        log.warn(usersErr:new(resp.err))
        return {}, response.internal_error({ err })
    end
    return meta_data
end
-- TODO wrap it in the pcall and validate phot name

function utils.get_field_attr(field_name, data)
    -- TODO pcall to exist the field_name on data.get
    local field = data:get(field_name)
    local name = ''
    local headers = ''
    -- TODO added here pcall function
    if field ~= nil and field.headers[1] ~= nil then
        headers = string.split(field.headers[1], ";")
        if headers[3] ~= nil then
            name = string.split(headers[3], "=")[2]
            name = string.split(name, '"')[2]
        end
    end

    return name, headers
end
-- check unsafe input field by array
function utils.filter_input_fields(check_field, fields)
    local checked_field = fields[check_field]
    local is_type_valid = {
        status = #check_field >= 1 and checked_field,
        err_msg = "Fio field should be great 1"
    }
    return is_type_valid, check_field
end
-- get key by value from table
function utils.get_key(t, value)
    for k, v in pairs(t) do
        if v == value then
            return k
        end
    end
    return nil
end

-- set path by key (sub folder)
function utils.set_path_img(path, key, data)
    -- get current index table
    -- get key of type_photo_index from current key
    if data ~= '' then
        local type_photo = utils.get_key(utils.PATH_IMG_TABLE, key)
        return path .. '/'.. type_photo .. '/' .. data
    end
    return ''
end
-- set path by key (sub folder)
function utils.set_one_path_img(path, type, data)
    -- get current index table
    -- get key of type_photo_index from current key
    if tostring(data) ~= '' then
        return path .. '/' .. type .. '/' .. data
    end
    return ''
end
-- crop image

function utils.crop_img(raw, params)
    -- get img
    local magick_status, img = pcall(magick.load_image_from_blob, raw)
    u.logger('crop_img raw', { raw = #raw, magick_status = magick_status, params })
    if magick_status ~= nil and params.height and params.width and params.x and
        params.y then
        img:crop(params.width, params.height, params.x, params.y)
        local img_blob = img:get_blob()
        img:destroy()
        return img_blob
    end
    log.error('image should parameters as width height x ,y for cropping')
    return raw
end
-- resize img
function utils.img_resize(raw, params)
    -- get img
    local magick_status, img = pcall(magick.load_image_from_blob, raw)
    local img_blob = ''
    if magick_status then
        --  img_blob = img:get_blob()
        if params.req_params ~= nil then
            img_blob = magick.thumb(img, params.req_params)
        else
            img:resize(params.width, params.height)
            img_blob = img:get_blob()
        end

        img:destroy()
        return img_blob
    end
    return raw
end

function utils.fill_unique_null(data)
    -- check data
    if type(data) ~= string and data == '' then
        data = 'null_' .. tostring(utils.gen_random_key(10))
    end
    return data
end

function utils.clean_unique_null(data)
    if string.match(data or '', '^null_[%d]+') ~= nil then
        data = ''
    end
    return data
end
-- is_pre_deleted if true then delete old file
function utils.convert_img(path, ext, is_pre_deleted)
    local is_pre_deleted = is_pre_deleted or false
    local result = { status = false, msg = 'file not found', path = '' }
    local file_name = string.split(path, '.')
    if fio.path.is_file(path) then
        u.logger('file_name', file_name)
        -- TODO check is it has dot of the begin
        if file_name[2] ~= nil then
            result.path = '.' .. file_name[2] .. '.' .. ext
            result.status = true
            result.msg = ''
        end
    end

    if result.status and os.execute('convert ' .. path .. ' ' .. result.path) == 0 then
        if is_pre_deleted then
            fio.unlink(path)
        end
        path = result.path
    end
    path = '.' .. file_name[2] .. '.' .. ext
    return path
end
-- replace file extension
function utils.replace_ext_of_file(name, ext)
    local status, result = pcall(function(_name, _ext)
        local img_name_arr = string.split(_name, '.')
        -- return if ext is same of file extension
        if (img_name_arr[2] == _ext) then
            return name
        end
        if img_name_arr[1] ~= nil then
            return img_name_arr[1] .. '.' .. _ext
        end
        return 'bad_name.' .. _ext

    end, name, ext)
    -- if is empty name then return name back
    if '.' .. ext == result then
        return name
    end

    return result
end

-- validate fio, login, email, password
function utils.check_field(var, msg)
    if var ~= nil then
        return var, { error = false }
    end

    return var, { error = true, msg = msg }
end

function utils.encrypt_password(password)
    return digest.sha512_hex(tostring(password) .. CONF.SALT)
end

-- send JSON data through server POST method
-- @params data type table
function utils.json_sender(url, data, header)
    -- convert to json
    local json_data = json.encode(data)
    local headers = { ['Content-Type'] = 'application/json' }
    if header ~= nil then
        for key, item in pairs(header) do
            headers[key] = item
        end

    end
    -- u.logger('headers', headers)
    -- u.logger('json_data', json_data)
    local request = http_client:post(url, json_data, { headers = headers })
    -- send to url by POST data
    -- return status
    return request.body, { status = request.status, reason = request.reason }
end

function utils.post_sender(url, data, header)
    -- convert to json
    local headers = { ['Content-Type'] = header.type }
    --if header ~= nil then
    --    for key, item in pairs(header) do
    --        headers[key] = item
    --    end
    --
    --end
    u.logger('headers', headers)
    -- u.logger('json_data', json_data)
    local request = http_client:post(url, data, { headers = headers })
    utils.logger("request", request)
    -- send to url by POST data
    -- return status
    return request.body, { status = request.status, reason = request.reason }
end
-- @param space
-- @param data [index, payload={{id=xxx, oder=1}, {...}}]
-- @return boolean of save
function utils.save_order(space, data)
    local result = {}
    -- switcher for order_list and order_main
    -- make loop and select id after update the order and if ok return result
    for _, item in ipairs(data.payload) do
        item['id'] = uuid.fromstr(item['id'])
        -- check id
        if box.space[space]:select(item['id']) then
            -- update order
            --
            local row = box.space[space]:update(item['id'], {
                { '=', data.index, item['order'] }
            })
            if row ~= nil then
                table.insert(result, row)
            end

        end
    end

    return #result == #data.payload
end
-- @param name
-- @param type
-- @return boolean
-- TODO make the function is general news/photo
function utils.delete_img(base_path, item)
    -- for key, val in pairs(type_photo_index) do
    -- calculate photo path
    -- TODO delete other images big mini items also
    local is_file_deleted = false
    --local file_path = '.' .. base_path .. '/' .. item.type .. '/' .. utils.replace_ext_of_file(item.name, 'webp') -- TODO slider
    local file_path = '.' .. base_path .. '/' .. item.type .. '/' ..  item.name -- TODO slider

    u.logger('path of deleted photo' .. item.type, file_path)
    if fio.path.is_file(file_path) then
        is_file_deleted = fio.unlink(file_path)
    end
    -- mini
    --local is_file_mini_deleted = false
    --local file_mini_path = '.' .. base_path .. '/mini_' .. item.type .. '/' .. utils.replace_ext_of_file(item.name, 'webp') -- TODO don't work here
    --    u.logger('path of deleted photo' .. 'mini', file_mini_path)
    --if fio.path.is_file(file_mini_path) then
    --    is_file_mini_deleted = fio.unlink(file_mini_path)
    --end
    -- return  is_file_deleted or is_file_mini_deleted
    return is_file_deleted
    -- end
end

-- validate input data
-- @param string|number variable
-- @return table {status, var, err}
-- validate input data
-- @param string|number variable
-- @return table {status, var, err}
function utils.is_valid_deprected(var, data)
    --length = type(var) == 'number' and #tostring(var) or #var
    --print(length)
    -- min_leng is not necessary
    data.min_leng = data.min_leng == nil and 0 or data.min_leng
    if data.min_leng <= #var and data.max_leng >= #var then
        --log.info(string.match(var, data.regex) == var)
        return string.match(var, data.regex) == var and true or false
    end
    return nil
end

function utils.is_string(var, param)
    local param = param or {}
    -- if var is nil then return default_param
    param.msg = param.msg or ""
    param.valid = false
    if type(var) == 'nil' or var == '' then
        param.msg = "Data isn't exist"
        -- it is for data which is empty
        param.valid = true
        return param.valid
    end

    if type(var) == 'string' then
        if param.min <= #var and param.max >= #var then
            local result = string.match(var, param.regex)
            if result == var then
                log.info('is string valid', true)
                param.valid = true
            end
        end

    end
    if param.valid == false then
        param.msg = 'var ' .. param.name .. ' ' .. tostring(var) .. ' is not valid string or min ' .. tonumber(param.min) .. ' or max' .. tonumber(param.max) .. ' length are not equal input variable'
        log.warn(param.msg)
    end
    u.logger('param_valid', param.valid)
    return param.valid
end

function utils.is_number(var, param)
    local param = param or {}
    -- if var is nil then return default_param
    param.msg = param.msg or ""
    param.valid = false
    if type(var) == 'number' then
        param.valid = true
    elseif var == nil then
        param.valid = true
    end
    if param.valid == false  then
        if type(var) == 'nil' then var = 0 end
        param.msg = 'var' .. tostring(param.name) .. ' ' .. tonumber(var) .. 'is not a number type'
    end
     log.warn(param.msg)
    return param.valid
end

--compare input some number
function utils.compare_number(var, operator, compare_number)
    if type(var) ~= 'number' then
        log.warn('it must be number')
        return var
    end
    -- less
    if '>=' == operator and var >= compare_number then
        return var
    end
    -- greater
    if '<=' == operator and var <= compare_number then
        return var
    end
    -- fix
    if '==' == operator and var == compare_number then
        return var
    end
end

function utils.is_timestamp(var, param)
    local param = param or {}
    -- if var is nil then return default_param
    param.msg = param.msg or ""
    param.valid = false

    if #(date(var):fmt('%d-%m-%Y')) == 10 then
        param.valid = true
    end
    if param.valid == false then
        param.msg = 'var is not date' .. tonumber(var)
        log.warn(param.msg)
    end

    return param.valid
end

function utils.is_bool(var, param)
    local param = param or {}
    -- if var is nil then return default_param
    param.msg = param.msg or ""
    param.valid = false
    if type(var) == 'boolean' then
        param.valid = true
    elseif var == nil then
        param.valid = true
    end
    if param.valid == false then
        param.msg = 'var is not date' .. tostring(var)
        log.warn(param.msg)

    end

    return param.valid
end

--write check function in_table
function utils.in_table(needle, haystack)
    for key, value in pairs(haystack) do
        if value == needle then
            return true
        end
    end
    return false
end

return utils
