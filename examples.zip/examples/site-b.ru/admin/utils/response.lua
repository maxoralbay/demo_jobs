local _json = require('json')
local CONFR = require('app.conf.response')

-- Возвращаем ошибку и код
local function json(body, head)
    if type(body) == 'table' then
        body = _json.encode(body)
    end
    
    local resp =  {
        status = 200,
        headers = {
            ['Content-Type'] = CONFR.HEADER_TYPE['json'],
            ['Access-Control-Allow-Origin'] = "*",
            ['access-control-allow-headers'] = CONFR.ALLOW_HEADERS,
            ['Access-Control-Expose-Headers'] = CONFR.EXPOSE_HEADERS,
            ['Access-Control-Allow-Credentials'] = true,
            ['Access-control-Max-Age'] = CONFR.MAX_AGE
            -- Добавить отключение кеша на cloudflare
        },
        timeout = CONFR.TIMEOUT,
        body = body
    }

    if type(head) == 'table' then
        for key, value in pairs(head) do
            resp.headers[key] = value
        end       
    end

    return resp
end

local function resp(body, head)
    if type(body) == 'table' then
        body = _json.encode(body)
    end

    local resp =  {
        status = 200,
        headers = {
            ['Content-Type'] = head.content_type or "application/json",
            ['Access-Control-Allow-Origin'] = "*",
            ['access-control-allow-headers'] = CONFR.ALLOW_HEADERS,
            ['Access-Control-Expose-Headers'] = CONFR.EXPOSE_HEADERS,
            ['Access-Control-Allow-Credentials'] = true,
            ['Access-control-Max-Age'] = CONFR.MAX_AGE
            -- Добавить отключение кеша на cloudflare
        },
        timeout = CONFR.TIMEOUT,
        body = body
    }

    if type(head) == 'table' then
        for key, value in pairs(head) do
            resp.headers[key] = value
        end
    end

    return resp
end
-- Возвращаем ошибку 404
local function not_found(body)
    local content = body or {msg = "404 not found"}
    local resp = json(content)
    resp.status = 404
    return resp
end

-- Редирект
local function redirect(location)
    local resp = {
        status = 301,
        headers = {
            ['Location'] = location,
            ['Server'] = CONFR.HEADER_SERVER,
            ['Content-Type'] = CONFR.HEADER_TYPE[type],
            ['Access-Control-Allow-Origin'] = CONFR.HEADER_ORIGIN,
        },
        timeout = CONFR.TIMEOUT
    }
    return resp
end

local function internal_error(error)
    local resp = json(error)
    resp.status = 500
    return resp
end

local function unauthorized(body, status)
    local resp = json(body)
    resp.status = status or 401
    return resp
end

-- list of exported function
local response = {
    resp = resp,
    internal_err = internal_error,
    json = json,
    not_found = not_found,
    unauth = unauthorized,
    redirect = redirect
}

return response
