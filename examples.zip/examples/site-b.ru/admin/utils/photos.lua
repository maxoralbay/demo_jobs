local u = require('app.utils.utils')
local fio_ext = require('app.utils.fio_ext')
local http_client = require('http.client').new({ max_connections = 5 })
local fio = require('fio')
local path_img = '/img/'
local photos = {}
local type_not_module = {'teams', 'users'}


function photos.save_img_file(path_img, file_name, raw, type_photo)
    local file_path = path_img
    local path_img_arr = string.split(path_img, '/')
    -- check if type_photo is in type_not_module
    if u.in_table(path_img_arr[#path_img_arr], type_not_module) then
        file_path = '.'..path_img .. '/' .. file_name
    else
        file_path = '.'..path_img .. '/' .. type_photo .. '/' .. file_name
    end
    local is_file_created = fio_ext.write(file_path, raw)
    u.logger('img_path', { img_path = file_path, is_file_created = is_file_created })
    return file_path

end


-- imaginary RESTAPI interface function
-- @return response photo_format
-- @example http://192.168.213.79:9000/fit?type=webp&width=120&height=200&url=https://i.ibb.co/0Vhypty/citlogo.png
-- photos.imginary_api('fit', { out_type='webp', file_path = './img/companies/logo/photo-147.jpeg', width=120, height=200, top=y, left=x})
-- @return table result of sending file
function photos.imginary_api(cmd, opts)
    local opts = opts or {}
    local msg = ''
    opts.out_type = opts.out_type or 'webp'
    local extension_arr = opts.file_name:split(".")
    local extension = extension_arr[#extension_arr]
    if extension == nil then
        msg = 'file has not extension'
        log.warn(msg)
        return {}
    end
    opts.type = 'image/'..extension -- calc of extension

    local cmd= cmd or 'fit'
    -- prepare params
    local params = cmd.."?".."type="..opts.out_type.."&width="..opts.width .. "&height="..opts.height
    if cmd == 'extract' then
        params = cmd.."?".."type="..opts.out_type.."&areawidth="..opts.width .. "&areaheight="..opts.height.."&top="..opts.top.."&left="..opts.left
    end
    -- send data to imginary api
    local headers = {["Content-Type"]=opts.type}
    u.logger('info request', {headers=headers, params=params})
    -- take file body from file
    u.logger("",CONF.IMGINARY_API..params, opts.file_raw, { headers = headers })
    local request = http_client:post(CONF.IMGINARY_API..params, opts.file_raw, { headers = headers })
    local result = { status = request.status, reason = request.reason , body = request.body}
    -- send to url by POST data
    -- return status
    if request.status ~=200 then
        msg = cmd ..": "..opts.file_name.." "..request.body
        log.warn(msg)
    end
    u.logger('utils photos msg', msg)
    return result.body, msg
end
return photos
