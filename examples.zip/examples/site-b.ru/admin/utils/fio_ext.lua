local fio = require('fio')
local errno = require('errno')
local log = require('error')
local utils = require('app.utils.utils')

local fio_ext = {}

-- Write data to file and recreate old file
-- @param filename = PATH..filename.ext
-- @param data is anything
-- @return bool: status
function fio_ext.write(filename, data)
    local f = fio.open(filename, { 'O_CREAT', 'O_WRONLY', 'O_APPEND' },
        tonumber('0666', 8))
    if not f then
        return false
    end
    -- delete if file exist
    f:truncate(0)
    f:write(data);
    f:close()
    return true
end

function fio_ext.create_folder(path)
    return fio.path.is_dir(path) == false and fio.mkdir(path) or false
end

function fio_ext.rm_folder(path)
    return fio.path.is_dir(path) == true and fio.rmtree(path) or false
end
return fio_ext
