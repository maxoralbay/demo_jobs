db = {}
-- return index as number of format
-- example: db.keys[ID] => 1
function db.keys(fmt)
    local keys = {}
    for i=1, #fmt do
        local key = fmt[i][1]:upper()
        keys[key] = i
    end
    -- save in the memory when init module and write it
    return keys
end
-- return type of field  as number of format
-- example: db.keys[ID] => 1
function db.type(fmt)
    local keys = {}
    for i=1, #fmt do
        local key = fmt[i][2]:upper()
        keys[key] = i
    end
    -- save in the memory when init module and write it
    return keys
end

return db